module.exports.workerTypes = {
  eager: "eager",
  sqs: "sqs",
  lambda: "lambda"
};
