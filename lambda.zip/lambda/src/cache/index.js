var memory;

memory = require('./memory');

module.exports = {
  memory: memory
};
