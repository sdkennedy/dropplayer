var actionKeys;

actionKeys = {
  indexService: 'indexService',
  indexSong: 'indexSong',
  removeSong: 'removeSong'
};

module.exports = {
  actionKeys: actionKeys
};
